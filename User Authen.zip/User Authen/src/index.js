const express = require('express');
const pasth = require("path")
const bcrypt = require("bcrypt")
const collection = require("./config ");
const { name } = require('ejs');
const { createCipheriv } = require('crypto');

const app = express();

//convsrting data to json format
app.use(express.json());

app.use(express.urlencoded({extended: false}));


//using ejs as view
app.set('view engine','ejs')

//static file
app.use(express.static("public")) 

app.get("/", (req,res) => {
    res.render("login")
})

app.get("/signup", (req,res) => {
    res.render("signup")
})

// For Registering User
app.post("/signup", async (req,res) => {

    const data = {
        name: req.body.username,
        password: req.body.password
    }

    //chekcing if user already exists
    const existingUser = await collection.findOne({name: data.name})

    if(existingUser) {
        res.send("User already exists. Please choose a different username.")
    }

    else{
        //hashing password
        const saltRounds = 10
        const hashedPassword = await bcrypt.hash(data.password, saltRounds)

        //replace original with hash
        data.password = hashedPassword

        const userdata = await collection.insertMany(data);
        console.log(userdata);
    }
})
//Register end

//For logging in user
app.post("/login", async (req,res) => {
    try {
        console.log("Request Body:", req.body); // Log request body to inspect username and password

        const { username, password } = req.body;

        if (!username || !password) {
            return res.send("Invalid username or password"); // Check if username or password is missing
        }

        const check = await collection.findOne({ name: username });

        if (!check) {
            return res.send("User not found");
        }

        const storedPassword = check.password;

        if (!storedPassword) {
            return res.send("User data incomplete");
        }

        const isPasswordMatch = await bcrypt.compare(password, storedPassword);

        if (isPasswordMatch) {
            res.render("home");
        } else {
            res.send("Wrong Password");
        }
    } catch (error) {
        console.error("Error in login:", error);
        res.send("Error during login");
    }
})

const port = 5000
app.listen(port, () => {
    console.log(`Server running on port : ${port}`);
})